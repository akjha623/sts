package test;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitionLogin {
	
	private Login log;
	
	
	@Given("^Login page is displayed and user already have the credentials$")
	public void login_page_is_displayed_and_user_already_have_the_credentials() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^when user enters username and password and clicks on login button$")
	public void when_user_enters_username_and_password_and_clicks_on_login_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^system displays welcome message$")
	public void system_displays_welcome_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
